# Thingworx Deployments

This is a repository of *helmsman* configurations for deploying Thingworx and its infrastructure. Currently, this sample assumes it is run in the Azure Kubernetes Service (AKS). Some simple PVC/StorageClass tweaks may be needed to make it run in other environments.

_Requires a helmsman version of at least 3.6.9+_

## Cluster Prerequisites
To prepare your cluster for the Thingworx Helmsman deployment:

1. Apply [cluster-setup/core.yaml](cluster-setup/core.yaml) which contains `cert-manager` and `kube-prometheus-stack`
     1. From `cluster-setup` directory, run: `helmsman -f core.yaml -apply`
1. Deploy the [cluster-setup/files-storage-class.yaml](cluster-setup/files-storage-class.yaml) file
     1. `kubectl apply -f ./files-storage-class.yaml`

## Deployments
Two sample deployments are provided:

1. [thingworx-standalone-example](thingworx-standalone-example) which deploys:
    1. Deploys a single-node Thingworx instance
    1. In-Cluster PostgreSQL
    1. InfluxDB

1. [thingworx-ha-example](thingworx-ha-example) which deploys:
    1. Deploys HA Thingworx with 2 nodes
    1. In-Cluster PostgreSQL
    1. InfluxDB
    1. Ignite (1 node)
    1. Zookeeper (3 nodes)
    1. Always-On Connection Server (2 nodes)

### How To Deploy
Each Deployment contains the following files:

| File | Description |
| --- | --- |
| common.env | Contains all required configuration for the deployments.
| common.yaml | Contains the helmsman deployment file for all applications. This contains the configuration for each deployment as well as deployment order.

Edit `common.env` to configure your Thingworx Container Registry and Thingworx Chart Repository. Change Image Tags and Chart Versions as needed. It is strongly suggested to change the default passwords provided in this file.

`common.yaml` should not need to be edited for initial sample deployments.

After `common.env` is updated with the required parameters, simply run the `helmsman` deployment:

```
helmsman -subst-env-values -f common.yaml -e common.env --apply
```

### Licensing
There are two options to include your ThingWorx license into the deployment.

#### Base64 Method
This method generates a base64 string of your license.bin that's then included in your configuration.
Run 

```
cat license.bin | base64
``` 

Set the output in `common.env` as `THINGWORX_LICENSE_VALUE: 'AAGFgAABS7....jw1w=='` 

If you are using a `license_capability_response.bin` file, set `THINGWORX_LICENSE_NAME: 'license_capability_response.bin'`

#### PTC Portal License Method

If you are using a PTC Portal License, in `thingworx.yaml` under the `commonConf` setting, uncomment and set the following to your credentials:

```
LS_USERNAME: myUsername
LS_PASSWORD: myPassword
```

### Alternative Databases
Samples are provided with alternative database configurations than just in-cluster PostgreSQL. See: [Alternative Databases](docs/DATABASE.md)

### Upgrades
See: [Upgrading Deployments](docs/UPGRADES.md)

## Thingworx Monitoring

To implement monitoring for services like Grafana, the following assumes the monitoring platform has an implementation that scans for Kubernetes ConfigMaps and uploads them as they are found.

Example

1. Create a dashboard in the format expected by the service monitoring platform. This example uses a sample JSON formatted file that can be found here [Memory Usage Dashboard Example](grafana/example-grafana-memory-usage-dashboard.json)
1. Upload the file to a ConfigMap
```
kubectl create configmap <configmap-name> --from-file=<dashboard-format-file-path>
```
1. Label the ConfigMap with the label the monitoring platform knows to look for so the dashboard can be added. Typically, the `grafana_dashboard: "1"` label is required for it to be picked up by grafana.
```
kubectl label configmap <configmap-name> grafana_dashboard="1"
kubectl label configmap <configmap-name> <label>=<value>
```

## Using Groups
In _common.yaml_ the applications are broken into "groups". You can effect just a group by
adding the _-group <name>_ parameter to the command line. It is also possible to add
multiple groups by adding multiple -group entries.
For example:

```
helmsman -subst-env-values -f common.yaml -e common.env --apply --group twx-setup
```

## Multiple Deployments in One Namespace
A Helmsman deployment attempts to manage the state for an entire namespace and will delete deployments that aren't part of that configuration.   

If making multiple Helmsman deployments into a single namespace add the `-keep-untracked-releases` flag.
