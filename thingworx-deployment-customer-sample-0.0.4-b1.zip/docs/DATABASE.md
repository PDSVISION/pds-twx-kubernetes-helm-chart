# Choosing a Database
The example deployment uses an "in Cluster" PostgreSQL database by default with the following parameters in `common.env`. The following will show how to use different databases as part of the deployment. There should only be one set of database parameters in `common.env` for the deployment. 

In the standalone example we also provide examples for how to configure alternative databases.

# Using In-Cluster mssql in Standalone Example
This mssql instance will be deployed as part of your kubernetes deployment.

1. In [common.yaml](../thingworx-standalone-example/common.yaml) set `enabled: false` for the ` ${DEPLOYMENT_NAME}-postgres` deployment.
1. Edit [mssql.env](../alternativeDatabases/mssql/mssql.env) to your mssql images.
1. Run `helmsman` from the `thingworx-standalone-example` directory to include the mssql example files:   
    1. `helmsman -subst-env-values -f common.yaml -f ../alternativeDatabases/mssql/mssql.yaml -e ../alternativeDatabases/mssql/mssql.env -e common.env --apply` 
    
# Using Azure hosted Postgres Database in Standalone Example
This is for connecting to an existing Azure Database for PostgreSQL server.

1. Configure Connection Security for your Azure Database for PostgreSQL to allow connections from the Azure Kubernetes cluster.  
1. In [common.yaml](../thingworx-standalone-example/common.yaml) set `enabled: false` for the ` ${DEPLOYMENT_NAME}-postgres` deployment.
1. Edit [azure-postgres.env](../alternativeDatabases/azure-postgres/azure-postgres.env) with credentials and the host URL to your Azure PostgreSQL server.
1. Run `helmsman` from the `thingworx-standalone-example` directory to include the Azure PostgresSQL example files:
    1. `helmsman -subst-env-values -f common.yaml -f ../alternativeDatabases/azure-postgres/azure-postgres.yaml -e ../alternativeDatabases/azure-postgres/azure-postgres.env -e common.env --apply` 

# Using Azure hosted Azure SQL Database in Standalone Example
This is for connecting to an existing Azure SQL Database.

1. Configure Connection Security for your Azure SQL Database to allow connections from the Azure Kubernetes cluster.
1. In [common.yaml](../thingworx-standalone-example/common.yaml) set `enabled: false` for the ` ${DEPLOYMENT_NAME}-postgres` deployment.
1. Edit [azure-postgres.env](../alternativeDatabases/azure-sql/azure-sql.env) with credentials and the host URL to your Azure SQL server.
1. Run `helmsman` from the `thingworx-standalone-example` directory to include the Azure SQL example files:
    1. `helmsman -subst-env-values -f common.yaml -f ../alternativeDatabases/azure-sql/azure-sql.yaml -e ../alternativeDatabases/azure-sql/azure-sql.env -e common.env --apply` 
