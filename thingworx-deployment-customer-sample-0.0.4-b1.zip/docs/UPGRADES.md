# Configuration Change

If you want to make configuration changes after deployment then update the appropriate configuration file and rerun the deploy for the applications specific group.  The change could be to environment variable or to values file directly.  It is much more efficient to use groups for deployment changes, it isolates the number of impacts.  The groups are defined in the common.env and can be changed if needed before running deploy commands.

## Scale up Ignite

#### Update configuration
In [ignite.yaml](../thingworx-ha-example/deployment/ignite.yaml) edit replicaCount then re-run the deployment:

```
helmsman -subst-env-values -f common.yaml -e common.env --apply -group ignite
```

# Upgrading Components
To upgrade component versions with breaking changes it is best to destroy the stateful sets and redeploy the applications. 

## Zookeeper
Zookeeper can not be directly upgraded without fully taking down thingworx, ignite and connection server. Zookeeper upgrades would include changing the cluster size or moving to a new version. This requires any apps that are using zookeeper be stopped first.

```
helmsman -subst-env-values -f common.yaml -e common.env -destroy -group zookeeper -group twx -group ignite -group cx
```

Make configuration changes and redeploy
```
helmsman -subst-env-values -f common.yaml -e common.env -apply -group zookeeper -group twx -group ignite -group cx
```

## Thingworx or Ignite

For a breaking upgrade, meaning a database schema change or changes to objects that affect serialization or other issues.   We will basically uninstall thingworx and ignite (they must always be done together). This will not affect the thingworx storage PVC since it is created separately. This step can be skipped if new and old versions can run together
```
helmsman -subst-env-values -f common.yaml -e common.env -destroy -group twx -group ignite
```

Make the configuration changes and redeploy. Ignite and thingworx will restart with the new changes.
```
helmsman -subst-env-values -f common.yaml -e common.env -apply -group twx -group ignite
```

*NOTE:* This can also be used for disaster recovery.

## Connection Server

Upgrading connection server will cause devices to disconnect and reconnect. It is important that we understand that all devices will attempt to move to other server instances and this can cause thundering herd behavior. Make sure there is sufficient capacity before beginning upgrade.

A rolling upgrade is probably sufficient. So make configuration changes and apply.
```
helmsman -subst-env-values -f common.yaml -e common.env -apply -group twx -group cx
```
